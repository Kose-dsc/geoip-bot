import discord
from discord.ext import commands
import aiohttp
import requests
import re
import typing
import instaloader
import os
from requests.exceptions import HTTPError, SSLError, RequestException
from urllib3.exceptions import InsecureRequestWarning
import warnings

DISCORD_TOKEN = "VOTRE TOKEN DE TON BOT"  

if not DISCORD_TOKEN:
    raise ValueError("Le token Discord n'est pas défini!")

intents = discord.Intents.default()
intents.typing = False
intents.message_content = True

warnings.filterwarnings("ignore", category=InsecureRequestWarning)
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

bot_prefix = "-"
bot = commands.Bot(command_prefix=bot_prefix, intents=intents)
bot.remove_command('help')

command_list = [
    ("Geoip <ip>", "Donne les informations de l'adresse IP."),
]


@bot.event
async def on_ready():
    print(f'{bot.user} est connecté!')
    bot.status = discord.Status.dnd
    activity = discord.Activity(type=discord.ActivityType.playing,
                                name="kose on top")
    await bot.change_presence(activity=activity)


def create_google_maps_link(city):
    return f"https://www.google.com/maps/place/{city.replace(' ', '+')}"


@bot.command()
async def Geoip(ctx, ip_address):
    try:
        response = requests.get(f"https://ipinfo.io/{ip_address}/json")
        response.raise_for_status()  

        data = response.json()

        ip = data.get('ip', 'N/A')
        hostname = data.get('hostname', 'N/A')
        city = data.get('city', 'N/A')
        region = data.get('region', 'N/A')
        country = data.get('country', 'N/A')
        postal = data.get('postal', 'N/A')
        loc = data.get('loc', 'N/A')
        org = data.get('org', 'N/A')
        timezone = data.get('timezone', 'N/A')

        google_maps_link = create_google_maps_link(city)

        embed = discord.Embed(title="Détails de l'Adresse IP", color=0x0800ff)
        embed.set_footer(text="kose on top")

        embed.set_thumbnail(
            url="https://media.discordapp.net/attachments/1305959873866891365/1309812539273777222/c06eb173-0cdf-48e3-87eb-9c0e734e9fc2-2.png"
        )  # mettre votre icon

        embed.add_field(name="IP",
                        value=ip,
                        inline=False)
        embed.add_field(name="Nom d'Hôte",
                        value=hostname,
                        inline=False)
        embed.add_field(name="🏙️   Ville", value=city, inline=False)
        embed.add_field(name="🌆   Région", value=region, inline=False)
        embed.add_field(name="🌍   Pays", value=country, inline=False)
        embed.add_field(name="📮   Code Postal", value=postal, inline=False)
        embed.add_field(name="📱   Coordonnées", value=loc, inline=False)
        embed.add_field(name="🛰️   Organisation", value=org, inline=False)
        embed.add_field(name="🕐   Fuseau Horaire",
                        value=timezone,
                        inline=False)
        embed.add_field(name="   Voir sur Google Maps",
                        value=f"[Cliquez ici]({google_maps_link})",
                        inline=False)

        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(f"Impossible de récupérer les informations IP : {e}")


bot.run(DISCORD_TOKEN)
